<?php


if(isset($_POST['upload'])){	
    
    //Db File
	include("db.php");
    // error_reporting(0);
	$heading=$_POST['heading'];
    // Count # of uploaded files in array
    $total = count($_FILES['images']['name']);

    // Loop through each file
    for( $i=0 ; $i < $total ; $i++ )
   {

      //Get the temp file path
      $tmpFilePath = $_FILES['images']['tmp_name'][$i];

      //Make sure we have a file path
      if ($tmpFilePath != ""){
        //Setup our new file path
        $newFilePath = "img/uploads/" . $_FILES['images']['name'][$i];

        if(move_uploaded_file($tmpFilePath, $newFilePath)) {
            // echo "INSERT INTO `footer` (`id`,`heading`,`image`)values(NULL,,'".$heading."''".$newFilePath."')";exit;
            //echo "INSERT INTO `gallery` (`id`,`images`)values(NULL,'".$newFilePath."')";
            $result = $db_handle->runQuery("INSERT INTO `footer` (`id`,`heading`,`image`)values(NULL,'".$heading."','".$newFilePath."')");
            echo '<script>alert(" Inserted Successfully ");
            window.location.href="footer.php"; </script>';


        }
      }
    }        

}

?>
