<?php
include("db.php");
 error_reporting(0);

$id= $_REQUEST["update_id"];
$name= $_REQUEST["edit_name"];
$email= $_REQUEST["edit_email"];
$phone= $_REQUEST["edit_phone"];
$comment= $_REQUEST["edit_comment"];
 {

		$result = $db_handle->runQuery("UPDATE `contact` SET  `name`='".$name."',`email`='".$email."' ,`phone`='".$phone."' ,`comment`='".$comment."' where id='".$id."'");
		echo '<script>alert(" Updated Successfully ");
		window.location.href="contact.php"; </script>';
	}

 


	?>