<?php

$keyId = 'rzp_test_0FZZ8lQZzWArW0';
$keySecret = 'p8qHmVz60omuftqynPObYgZU';
$displayCurrency = 'INR';

//These should be commented out in production
// This is for error reporting
// Add it to config.php to report any errors
error_reporting(E_ALL);
ini_set('display_errors', 1);


//DATABASE CONNECTION DETAILS
$host = "localhost";
$username = "root";
$password = "";
$dbname = "ngo";