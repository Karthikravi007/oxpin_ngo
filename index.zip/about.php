<?php include 'header.php' ?>
        <!--Page Header Start-->
        <section class="page-header">
            <div class="page-header-bg" style="background-image: url(assets/images/backgrounds/page-header-bg.jpg)">
            </div>
            <div class="container">
                <div class="page-header__inner">
                    <ul class="thm-breadcrumb list-unstyled">
                        <li><a href="index.php">Home</a></li>
                        <li><span>/</span></li>
                        <li class="active">Pages</li>
                    </ul>
                    <h2>About us</h2>
                </div>
            </div>
        </section>
        <!--Page Header End-->

        <!--About Four Start-->
        <section class="about-four">
            <div class="container">
                <div class="row">
                    <div class="col-xl-6">
                        <div class="about-four__left">
                            <div class="about-four__img-box">
                                <div class="about-four__img">
                                    <img src="assets/images/resources/about-four-img-1.jpg" alt="">
                                </div>
                                <div class="about-four__img-two">
                                    <img src="assets/images/resources/about-four-img-2.jpg" alt="">
                                </div>
                                <div class="about-four__border"></div>
                            </div>
                        </div>
                    </div>
                    <div class="col-xl-6">
                        <div class="about-four__right">
                            <div class="section-title text-left">
                                <span class="section-title__tagline">About oxpins</span>
                                <h2 class="section-title__title">Get to know about our
                                    oxpins organization</h2>
                            </div>
                            <p class="about-four__text">Nam ultrices odio a felis lobortis convallis. In ex nunc, ornare
                                non condimentum et, egestas vel massa. Nullam hendrerit felis quis pellentesque
                                porttitor. Aenean lobortis bibendum turpis et auctor. Nam iaculis, lectus vulputate
                                cursus interdum.</p>
                            <ul class="list-unstyled about-four__points">
                                <li>
                                    <div class="icon">
                                        <i class="fa fa-check"></i>
                                    </div>
                                    <div class="text">
                                        <p>Proin sed magna vel mi suscipit commodo.</p>
                                    </div>
                                </li>
                                <li>
                                    <div class="icon">
                                        <i class="fa fa-check"></i>
                                    </div>
                                    <div class="text">
                                        <p>Cras aliquet nulla ut varius blandit.</p>
                                    </div>
                                </li>
                                <li>
                                    <div class="icon">
                                        <i class="fa fa-check"></i>
                                    </div>
                                    <div class="text">
                                        <p>Nulla auctor ipsum sed nisi lis porttitor.</p>
                                    </div>
                                </li>
                            </ul>
                            <div class="about-four__btn-box">
                                <a href="about.php" class="thm-btn about-four__btn">Discover More</a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <!--About Four End-->

        <!--Testimonial Two Start-->
        <section class="testimonial-one" style="margin-top:20px;margin-bottom:20px;">
            <div class="testimonial-one-bg jarallax" data-jarallax data-speed="0.2" data-imgPosition="50% 0%"
                style="background-image: url(assets/images/backgrounds/testimonial-one-bg.jpg);"></div>
            <div class="container">
                <div class="row">
                    <div class="col-xl-6 col-lg-6">
                        <div class="testimonial-one__left">
                            <div class="section-title text-left">
                                <span class="section-title__tagline">Our Testimonials</span>
                                <h2 class="section-title__title">What they are talking about oxpins</h2>
                            </div>
                            <p class="testimonial-one__text-1">Nulla ultricies justo sit amet ante efficitur, eget
                                pharetra augue efficitur. Vestibulum viverra, dolor sit amet ultricies ornare, elit
                                justo pretium tellus.</p>
                            <a href="#" class="thm-btn testimonial-one__btn">all testimonials</a>
                        </div>
                    </div>
                    <div class="col-xl-6 col-lg-6">
                        <div class="testimonial-one__right">
                            <div class="testimonial-one__img-1 zoom-fade">
                                <img src="assets/images/testimonial/testimonial-img-1.jpg" alt="">
                            </div>
                            <div class="testimonial-one__img-1 testimonial-one__img-2 zoom-fade">
                                <img src="assets/images/testimonial/testimonial-img-2.jpg" alt="">
                            </div>
                            <div class="testimonial-one__img-1 testimonial-one__img-3 zoom-fade">
                                <img src="assets/images/testimonial/testimonial-img-3.jpg" alt="">
                            </div>
                            <div class="testimonial-one__img-1 testimonial-one__img-4 zoom-fade">
                                <img src="assets/images/testimonial/testimonial-img-4.jpg" alt="">
                            </div>
                            <div class="testimonial-one__carousel owl-carousel owl-theme thm-owl__carousel"
                                data-owl-options='{
                                "loop": true,
                                "autoplay": true,
                                "margin": 50,
                                "nav": true,
                                "dots": false,
                                "smartSpeed": 500,
                                "autoplayTimeout": 10000,
                                "navText": ["<span class=\"icon-left-arrow\"></span>","<span class=\"icon-right-arrow\"></span>"],
                                "responsive": {
                                    "0": {
                                        "items": 1
                                    },
                                    "768": {
                                        "items": 1
                                    },
                                    "992": {
                                        "items": 1
                                    },
                                    "1200": {
                                        "items": 1
                                    }
                                }
                            }'>
                                <div class="item">
                                    <!--Testimonial One Single Start-->
                                    <div class="testimonial-one__single">
                                        <div class="testimonial-one__shape-1"
                                            style="background-image: url(assets/images/shapes/testimonial-one-shape-1.png);">
                                        </div>
                                        <div class="testimonial-one__client-img">
                                            <img src="assets/images/testimonial/testimonial-1-1.jpg" alt="">
                                        </div>
                                        <div class="testimonial-one__client-info">
                                            <h3 class="testimonial-one__client-name">Kevin martin</h3>
                                            <p class="testimonial-one__client-sub-title">Volunteer</p>
                                        </div>
                                        <div class="testimonial-one__quote">
                                            <span class="icon-double-quotes"></span>
                                        </div>
                                        <p class="testimonial-one__text-2">Nulla ultricies justo sit amet ante
                                            efficitur, eget pharetra augue efficitur. Vestibulum viverra, dolor sit amet
                                            ultricies simply free text ornare, elit justo pretium tellus.</p>
                                    </div>
                                    <!--Testimonial One Single End-->
                                </div>
                                <div class="item">
                                    <!--Testimonial One Single Start-->
                                    <div class="testimonial-one__single">
                                        <div class="testimonial-one__shape-1"
                                            style="background-image: url(assets/images/shapes/testimonial-one-shape-1.png);">
                                        </div>
                                        <div class="testimonial-one__client-img">
                                            <img src="assets/images/testimonial/testimonial-1-2.jpg" alt="">
                                        </div>
                                        <div class="testimonial-one__client-info">
                                            <h3 class="testimonial-one__client-name">Jessica brown</h3>
                                            <p class="testimonial-one__client-sub-title">Volunteer</p>
                                        </div>
                                        <div class="testimonial-one__quote">
                                            <span class="icon-double-quotes"></span>
                                        </div>
                                        <p class="testimonial-one__text-2">Nulla ultricies justo sit amet ante
                                            efficitur, eget pharetra augue efficitur. Vestibulum viverra, dolor sit amet
                                            ultricies simply free text ornare, elit justo pretium tellus.</p>
                                    </div>
                                    <!--Testimonial One Single End-->
                                </div>
                                <div class="item">
                                    <!--Testimonial One Single Start-->
                                    <div class="testimonial-one__single">
                                        <div class="testimonial-one__shape-1"
                                            style="background-image: url(assets/images/shapes/testimonial-one-shape-1.png);">
                                        </div>
                                        <div class="testimonial-one__client-img">
                                            <img src="assets/images/testimonial/testimonial-1-3.jpg" alt="">
                                        </div>
                                        <div class="testimonial-one__client-info">
                                            <h3 class="testimonial-one__client-name">Mike hardson</h3>
                                            <p class="testimonial-one__client-sub-title">Volunteer</p>
                                        </div>
                                        <div class="testimonial-one__quote">
                                            <span class="icon-double-quotes"></span>
                                        </div>
                                        <p class="testimonial-one__text-2">Nulla ultricies justo sit amet ante
                                            efficitur, eget pharetra augue efficitur. Vestibulum viverra, dolor sit amet
                                            ultricies simply free text ornare, elit justo pretium tellus.</p>
                                    </div>
                                    <!--Testimonial One Single End-->
                                </div>
                                <div class="item">
                                    <!--Testimonial One Single Start-->
                                    <div class="testimonial-one__single">
                                        <div class="testimonial-one__shape-1"
                                            style="background-image: url(assets/images/shapes/testimonial-one-shape-1.png);">
                                        </div>
                                        <div class="testimonial-one__client-img">
                                            <img src="assets/images/testimonial/testimonial-1-1.jpg" alt="">
                                        </div>
                                        <div class="testimonial-one__client-info">
                                            <h3 class="testimonial-one__client-name">Kevin martin</h3>
                                            <p class="testimonial-one__client-sub-title">Volunteer</p>
                                        </div>
                                        <div class="testimonial-one__quote">
                                            <span class="icon-double-quotes"></span>
                                        </div>
                                        <p class="testimonial-one__text-2">Nulla ultricies justo sit amet ante
                                            efficitur, eget pharetra augue efficitur. Vestibulum viverra, dolor sit amet
                                            ultricies simply free text ornare, elit justo pretium tellus.</p>
                                    </div>
                                    <!--Testimonial One Single End-->
                                </div>
                                <div class="item">
                                    <!--Testimonial One Single Start-->
                                    <div class="testimonial-one__single">
                                        <div class="testimonial-one__shape-1"
                                            style="background-image: url(assets/images/shapes/testimonial-one-shape-1.png);">
                                        </div>
                                        <div class="testimonial-one__client-img">
                                            <img src="assets/images/testimonial/testimonial-1-2.jpg" alt="">
                                        </div>
                                        <div class="testimonial-one__client-info">
                                            <h3 class="testimonial-one__client-name">Jessica brown</h3>
                                            <p class="testimonial-one__client-sub-title">Volunteer</p>
                                        </div>
                                        <div class="testimonial-one__quote">
                                            <span class="icon-double-quotes"></span>
                                        </div>
                                        <p class="testimonial-one__text-2">Nulla ultricies justo sit amet ante
                                            efficitur, eget pharetra augue efficitur. Vestibulum viverra, dolor sit amet
                                            ultricies simply free text ornare, elit justo pretium tellus.</p>
                                    </div>
                                    <!--Testimonial One Single End-->
                                </div>
                                <div class="item">
                                    <!--Testimonial One Single Start-->
                                    <div class="testimonial-one__single">
                                        <div class="testimonial-one__shape-1"
                                            style="background-image: url(assets/images/shapes/testimonial-one-shape-1.png);">
                                        </div>
                                        <div class="testimonial-one__client-img">
                                            <img src="assets/images/testimonial/testimonial-1-3.jpg" alt="">
                                        </div>
                                        <div class="testimonial-one__client-info">
                                            <h3 class="testimonial-one__client-name">Mike hardson</h3>
                                            <p class="testimonial-one__client-sub-title">Volunteer</p>
                                        </div>
                                        <div class="testimonial-one__quote">
                                            <span class="icon-double-quotes"></span>
                                        </div>
                                        <p class="testimonial-one__text-2">Nulla ultricies justo sit amet ante
                                            efficitur, eget pharetra augue efficitur. Vestibulum viverra, dolor sit amet
                                            ultricies simply free text ornare, elit justo pretium tellus.</p>
                                    </div>
                                    <!--Testimonial One Single End-->
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <!--Testimonial Two End-->

        <!--Become Volunteer One Start-->
        <section class="become-volunteer-one">
            <div class="become-volunteer-one__bg-box">
                <div class="become-volunteer-one__bg jarallax" data-jarallax data-speed="0.2" data-imgPosition="50% 0%"
                    style="background-image: url(assets/images/backgrounds/become-volunteer-one-bg.jpg);"></div>
            </div>
            <div class="become-volunteer-one__shape-1"
                style="background-image: url(assets/images/shapes/become-volunteer-shape-1.png);"></div>
            <div class="container">
                <div class="become-volunteer-one__inner">
                    <p class="become-volunteer-one__sub-title">Become a Volunteers</p>
                    <h3 class="become-volunteer-one__title">Join your hand with us for a <br> better life and future
                    </h3>
                    <div class="become-volunteer-one__btn-box">
                        <a href="#!" class="thm-btn become-volunteer-one__btn">Discover More</a>
                    </div>
                </div>
            </div>
        </section>
        <!--Become Volunteer One End-->
       

        <?php include 'footer.php' ?>