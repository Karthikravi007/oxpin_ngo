<?php include 'header.php' ?>
        <!--Main Slider Start-->
        <section class="main-slider clearfix">
            <div class="swiper-container thm-swiper__slider" data-swiper-options='{"slidesPerView": 1, "loop": true,
                "effect": "fade",
                "pagination": {
                "el": "#main-slider-pagination",
                "type": "bullets",
                "clickable": true
                },
                "navigation": {
                "nextEl": "#main-slider__swiper-button-next",
                "prevEl": "#main-slider__swiper-button-prev"
                },
                "autoplay": {
                "delay": 5000
                }}'>
                <div class="swiper-wrapper">
                <?php
$result = $db_handle->runQuery("select * from slider");

foreach($result as $row) { ?>
                    <div class="swiper-slide">
                        <div class="image-layer"
                            style="background-image: url(admin/<?php echo $row['image'];?>);"></div>
                        <!-- /.image-layer -->

                        <div class="main-slider-shape-1"
                            style="background-image: url(assets/images/shapes/main-slider-shape-1.jpg);"></div>
                        <div class="main-slider-shape-2 float-bob-x">
                            <img src="assets/images/shapes/main-slider-shape-2.png" alt="">
                        </div>

                        <div class="container">
                            <div class="row">
                                <div class="col-xl-6 col-lg-8">
                                    <div class="main-slider__content">
                                        <p class="main-slider__sub-title"><?php echo $row['heading'];?></p>
                                        <h2 class="main-slider__title"><?php echo $row['subheading'];?></h2>
                                        <!-- <div class="main-slider__btn-box">
                                            <a href="about.php" class="thm-btn main-slider__btn"> Discover more</a>
                                        </div> -->
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
<?php } ?>
                </div>

                <!-- If we need navigation buttons -->
                <div class="main-slider__nav">
                    <div class="swiper-button-prev" id="main-slider__swiper-button-next">
                        <i class="icon-left-arrow"></i>
                    </div>
                    <div class="swiper-button-next" id="main-slider__swiper-button-prev">
                        <i class="icon-right-arrow"></i>
                    </div>
                </div>

            </div>
        </section>
        <!--Main Slider End-->

        <!--About One Start-->
        <section class="about-one">
            <div class="about-one__shape-box-1">
                <div class="about-one__shape-1"
                    style="background-image: url(assets/images/shapes/about-one-shape-1.png);"></div>
            </div>
            <div class="container">
            <?php
$result = $db_handle->runQuery("select * from mini_about");

foreach($result as $row) { ?>
                <div class="row">
                    <div class="col-xl-6">
                        <div class="about-one__left">
                            <div class="about-one__img-box wow slideInLeft" data-wow-delay="100ms"
                                data-wow-duration="2500ms">
                                <div class="about-one__img">
                                    <img src="admin/<?php echo $row['image'];?>" alt="">
                                </div>
                                <div class="about-one__img-border"></div>
                                
                                <div class="about-one__shape-2 zoom-fade">
                                    <img src="assets/images/shapes/about-one-shape-2.png" alt="">
                                </div>
                                <div class="about-one__shape-3 float-bob-y">
                                    <img src="assets/images/shapes/about-one-shape-3.png" alt="">
                                </div>
                                <div class="about-one__shape-4 zoominout">
                                    <img src="assets/images/shapes/about-one-shape-4.png" alt="">
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-xl-6">
                        <div class="about-one__right">
                            <div class="section-title text-left">
                                <span class="section-title__tagline"><?php echo $row['exprience'];?></span>
                                <h2 class="section-title__title"><?php echo $row['heading'];?></h2>
                            </div>
                            <p class="about-one__text"><?php echo $row['description'];?></p>
                            <div class="about-one__fund">
                               </div>
                            <ul class="list-unstyled about-one__points">
                                <li>
                                    <div class="icon">
                                        <span class="icon-volunteer"></span>
                                    </div>
                                    <div class="text">
                                        <h5><a href="#!"><?php echo $row['subheading1'];?></a></h5>
                                        <p><?php echo $row['description1'];?></p>
                                    </div>
                                </li>
                                <li>
                                    <div class="icon">
                                        <span class="icon-solidarity"></span>
                                    </div>
                                    <div class="text">
                                        <h5><a href="donate.php"><?php echo $row['subheading2'];?></a></h5>
                                        <p><?php echo $row['description2'];?></p>
                                    </div>
                                </li>
                            </ul>
                            <a href="about.php" class="thm-btn about-one__btn">Discover More</a>
                        </div>
                    </div>
                <?php } ?>
                </div>
            </div>
        </section>
        <!--About One End-->

        <!--Causes One Start-->
        <section class="causes-one">
            <div class="container">
                <div class="section-title text-center">
                    <span class="section-title__tagline">Help & donate us now</span>
                    <h2 class="section-title__title">Find the popular cause <br> and donate them</h2>
                </div>
                <div class="row">
                    <!--Causes One Single Start-->
                    <div class="col-xl-4 col-lg-4 wow fadeInUp" data-wow-delay="100ms">
                        <div class="causes-one__single">
                            <div class="causes-one__img">
                                <img src="assets/images/resources/causes-1-1.jpg" alt="">
                                <div class="causes-one__cat">
                                    <p>Education</p>
                                </div>
                            </div>
                            <div class="causes-one__content">
                                <h3 class="causes-one__title"><a href="donate.php">Let’s education for
                                        children get good life</a>
                                </h3>
                                <p class="causes-one__text">There are many of lorem, but majori have
                                    suffered alteration in some form.</p>
                                <div class="causes-one__progress">
                                    <div class="causes-one__progress-shape"
                                        style="background-image: url(assets/images/shapes/causes-one-progress-shape-1.png);">
                                    </div>
                                    <div class="bar">
                                        <div class="bar-inner count-bar" data-percent="36%">
                                            <div class="count-text">36%</div>
                                        </div>
                                    </div>
                                    <div class="causes-one__goals">
                                        <p><span>$25,270</span> Raised</p>
                                        <p><span>$30,000</span> Goal</p>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <!--Causes One Single End-->
                    <!--Causes One Single Start-->
                    <div class="col-xl-4 col-lg-4 wow fadeInUp" data-wow-delay="200ms">
                        <div class="causes-one__single">
                            <div class="causes-one__img">
                                <img src="assets/images/resources/causes-1-2.jpg" alt="">
                                <div class="causes-one__cat">
                                    <p>Medical</p>
                                </div>
                            </div>
                            <div class="causes-one__content">
                                <h3 class="causes-one__title"><a href="donate.php">It is a long established
                                        fact that a reader</a>
                                </h3>
                                <p class="causes-one__text">There are many of lorem, but majori have
                                    suffered alteration in some form.</p>
                                <div class="causes-one__progress">
                                    <div class="causes-one__progress-shape"
                                        style="background-image: url(assets/images/shapes/causes-one-progress-shape-1.png);">
                                    </div>
                                    <div class="bar">
                                        <div class="bar-inner count-bar" data-percent="36%">
                                            <div class="count-text">36%</div>
                                        </div>
                                    </div>
                                    <div class="causes-one__goals">
                                        <p><span>$25,270</span> Raised</p>
                                        <p><span>$30,000</span> Goal</p>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <!--Causes One Single End-->
                    <!--Causes One Single Start-->
                    <div class="col-xl-4 col-lg-4 wow fadeInUp" data-wow-delay="300ms">
                        <div class="causes-one__single">
                            <div class="causes-one__img">
                                <img src="assets/images/resources/causes-1-3.jpg" alt="">
                                <div class="causes-one__cat">
                                    <p>Food</p>
                                </div>
                            </div>
                            <div class="causes-one__content">
                                <h3 class="causes-one__title"><a href="donate.php">There are many variations
                                        of passages</a>
                                </h3>
                                <p class="causes-one__text">There are many of lorem, but majori have
                                    suffered alteration in some form.</p>
                                <div class="causes-one__progress">
                                    <div class="causes-one__progress-shape"
                                        style="background-image: url(assets/images/shapes/causes-one-progress-shape-1.png);">
                                    </div>
                                    <div class="bar">
                                        <div class="bar-inner count-bar" data-percent="36%">
                                            <div class="count-text">36%</div>
                                        </div>
                                    </div>
                                    <div class="causes-one__goals">
                                        <p><span>$25,270</span> Raised</p>
                                        <p><span>$30,000</span> Goal</p>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <!--Causes One Single End-->
                </div>
            </div>
        </section>
        <!--Causes One End-->

        <!--Become Volunteer One Start-->
        <?php
$result = $db_handle->runQuery("select * from content");

foreach($result as $row) { ?>
        <section class="become-volunteer-one">
            <div class="become-volunteer-one__bg-box">
                <div class="become-volunteer-one__bg jarallax" data-jarallax data-speed="0.2" data-imgPosition="50% 0%"
                    style="background-image: url(admin/<?php echo $row['image'];?>);"></div>
            </div>
            <div class="become-volunteer-one__shape-1"
                style="background-image: url(assets/images/shapes/become-volunteer-shape-1.png);"></div>
            <div class="container">
                <div class="become-volunteer-one__inner">
                    <p class="become-volunteer-one__sub-title"><?php echo $row['heading'];?></p>
                    <h3 class="become-volunteer-one__title"><?php echo $row['subheading'];?>
                    </h3>
                    <div class="become-volunteer-one__btn-box">
                        <a href="#!" class="thm-btn become-volunteer-one__btn">Discover More</a>
                    </div>
                </div>
            </div>
        </section>
        <?php } ?>
        <!--Become Volunteer One End-->

        <!--Events One Start-->
        <section class="events-one">
            <div class="events-one-shape-1" style="background-image: url(assets/images/shapes/events-one-shape-1.png)">
            </div>
            <div class="container">
                <div class="row">
                    <!-- <div class="col-xl-4 col-lg-4">
                        <div class="events-one__left">
                            <div class="section-title text-left">
                                <span class="section-title__tagline">Upcoming events</span>
                                <h2 class="section-title__title">Join our latest upcoming events</h2>
                            </div>
                            <p class="events-one__text-1">There are many variations of passages of lorem ipsum available
                                but the majority have suffered.</p>
                            <a href="events.php" class="thm-btn events-one__btn">Discover More</a>
                        </div>
                    </div> -->
                    <div class="col-xl-12 col-lg-12">
                        <div class="events-one__right">
                            <div class="events-one__carousel owl-carousel owl-theme thm-owl__carousel" data-owl-options='{
                                "loop": true,
                                "autoplay": true,
                                "margin": 20,
                                "nav": true,
                                "dots": false,
                                "smartSpeed": 500,
                                "autoplayTimeout": 10000,
                                "navText": ["<span class=\"icon-left-arrow\"></span>","<span class=\"icon-right-arrow\"></span>"],
                                "responsive": {
                                    "0": {
                                        "items": 1
                                    },
                                    "768": {
                                        "items": 3
                                    },
                                    "992": {
                                        "items": 3
                                    },
                                    "1200": {
                                        "items": 4
                                    }
                                }
                            }'>
                            <?php
$result = $db_handle->runQuery("select * from event");

foreach($result as $row) { ?>
                                <div class="item">
                                    <!--Events One Single Start-->
                                    <div class="events-one__single">
                                        <div class="events-one__img">
                                            <img src="admin/<?php echo $row['image'];?>" alt="">
                                            <div class="events-one__date">
                                                <p><?php echo $row['date'];?></p>
                                            </div>
                                            <div class="events-one__content">
                                                <h3 class="events-one__title"><a href="events.php"><?php echo $row['heading'];?></a></h3>
                                            </div>
                                        </div>
                                    </div>
                                    <!--Events One Single End-->
                                </div>
                                <?php } ?>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <!--Events One End-->

        <!--Feature One Start-->
        <section class="feature-one">
            <div class="container">
                <div class="row">
                    <div class="col-xl-6 col-lg-6  wow slideInLeft" data-wow-delay="100ms" data-wow-duration="2500ms">
                        <div class="feature-one__single">
                            <div class="feature-one__single-bg"
                                style="background-image: url(assets/images/shapes/feature-one-shape-1.png);"></div>
                            <div class="feature-one__top">
                                <div class="feature-one__top-inner">
                                    <div class="feature-one__top-icon">
                                        <span class="icon-help"></span>
                                    </div>
                                    <div class="feature-one__top-title-box">
                                        <h3 class="feature-one__top-title"><a href="#!">Join us &
                                                become <br> a
                                                volunteer</a></h3>
                                    </div>
                                </div>
                            </div>
                            <p class="feature-one__text">Mauris feugiat at orci ac congue. mauris ut <br> lacus quis
                                proin
                                diam.</p>
                            <ul class="list-unstyled feature-one__point">
                                <li>
                                    <div class="icon">
                                        <span class="fa fa-check"></span>
                                    </div>
                                    <div class="text">
                                        <p>Sed et nulla a nunc finibus eleifend.</p>
                                    </div>
                                </li>
                                <li>
                                    <div class="icon">
                                        <span class="fa fa-check"></span>
                                    </div>
                                    <div class="text">
                                        <p>Mauris nulla nisl, pellentesque vetae.</p>
                                    </div>
                                </li>
                                <li>
                                    <div class="icon">
                                        <span class="fa fa-check"></span>
                                    </div>
                                    <div class="text">
                                        <p>Proin quis aliquam nisi.</p>
                                    </div>
                                </li>
                            </ul>
                            <a href="#!" class="thm-btn feature-one__btn">View details</a>
                        </div>
                    </div>
                    <div class="col-xl-6 col-lg-6  wow slideInRight" data-wow-delay="100ms" data-wow-duration="2500ms">
                        <div class="feature-one__single feature-one__single--two">
                            <div class="feature-one__single-bg"
                                style="background-image: url(assets/images/shapes/feature-one-shape-1.png);"></div>
                            <div class="feature-one__top">
                                <div class="feature-one__top-inner">
                                    <div class="feature-one__top-icon feature-one__top-icon--two">
                                        <span class="icon-gift-box"></span>
                                    </div>
                                    <div class="feature-one__top-title-box">
                                        <h3 class="feature-one__top-title"><a href="about.php">Send
                                                a gift for <br>
                                                childrens</a></h3>
                                    </div>
                                </div>
                            </div>
                            <p class="feature-one__text">Mauris feugiat at orci ac congue. mauris ut <br> lacus quis
                                proin
                                diam.</p>
                            <ul class="list-unstyled feature-one__point">
                                <li>
                                    <div class="icon">
                                        <span class="fa fa-check"></span>
                                    </div>
                                    <div class="text">
                                        <p>Sed et nulla a nunc finibus eleifend.</p>
                                    </div>
                                </li>
                                <li>
                                    <div class="icon">
                                        <span class="fa fa-check"></span>
                                    </div>
                                    <div class="text">
                                        <p>Mauris nulla nisl, pellentesque vetae.</p>
                                    </div>
                                </li>
                                <li>
                                    <div class="icon">
                                        <span class="fa fa-check"></span>
                                    </div>
                                    <div class="text">
                                        <p>Proin quis aliquam nisi.</p>
                                    </div>
                                </li>
                            </ul>
                            <a href="about.php" class="thm-btn feature-one__btn">View details</a>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <!--Feature One End-->
        <!--Testimonial One Start-->
        <section class="testimonial-one">
            <div class="testimonial-one-bg jarallax" data-jarallax data-speed="0.2" data-imgPosition="50% 0%"
                style="background-image: url(assets/images/backgrounds/testimonial-one-bg.jpg);"></div>
            <div class="container">
                <div class="row">
                    <div class="col-xl-2 col-lg-2">
                       
                    </div>
                    <div class="col-xl-8 col-lg-8">
                        <div class="testimonial-one__right">
                            <div class="testimonial-one__img-1 zoom-fade">
                                <img src="assets/images/testimonial/testimonial-img-1.jpg" alt="">
                            </div>
                            <div class="testimonial-one__img-1 testimonial-one__img-2 zoom-fade">
                                <img src="assets/images/testimonial/testimonial-img-2.jpg" alt="">
                            </div>
                            <div class="testimonial-one__img-1 testimonial-one__img-3 zoom-fade">
                                <img src="assets/images/testimonial/testimonial-img-3.jpg" alt="">
                            </div>
                            <div class="testimonial-one__img-1 testimonial-one__img-4 zoom-fade">
                                <img src="assets/images/testimonial/testimonial-img-4.jpg" alt="">
                            </div>
                            <div class="testimonial-one__carousel owl-carousel owl-theme thm-owl__carousel"
                                data-owl-options='{
                                "loop": true,
                                "autoplay": true,
                                "margin": 50,
                                "nav": true,
                                "dots": false,
                                "smartSpeed": 500,
                                "autoplayTimeout": 10000,
                                "navText": ["<span class=\"icon-left-arrow\"></span>","<span class=\"icon-right-arrow\"></span>"],
                                "responsive": {
                                    "0": {
                                        "items": 1
                                    },
                                    "768": {
                                        "items": 1
                                    },
                                    "992": {
                                        "items": 1
                                    },
                                    "1200": {
                                        "items": 1
                                    }
                                }
                            }'>
                                <div class="item">
                                    <!--Testimonial One Single Start-->
                                    <div class="testimonial-one__single">
                                        <div class="testimonial-one__shape-1"
                                            style="background-image: url(assets/images/shapes/testimonial-one-shape-1.png);">
                                        </div>
                                        <div class="testimonial-one__client-img">
                                            <img src="assets/images/testimonial/testimonial-1-1.jpg" alt="">
                                        </div>
                                        <div class="testimonial-one__client-info">
                                            <h3 class="testimonial-one__client-name">Kevin martin</h3>
                                            <p class="testimonial-one__client-sub-title">Volunteer</p>
                                        </div>
                                        <div class="testimonial-one__quote">
                                            <span class="icon-double-quotes"></span>
                                        </div>
                                        <p class="testimonial-one__text-2">Nulla ultricies justo sit amet ante
                                            efficitur, eget pharetra augue efficitur. Vestibulum viverra, dolor sit amet
                                            ultricies simply free text ornare, elit justo pretium tellus.</p>
                                    </div>
                                    <!--Testimonial One Single End-->
                                </div>
                                <div class="item">
                                    <!--Testimonial One Single Start-->
                                    <div class="testimonial-one__single">
                                        <div class="testimonial-one__shape-1"
                                            style="background-image: url(assets/images/shapes/testimonial-one-shape-1.png);">
                                        </div>
                                        <div class="testimonial-one__client-img">
                                            <img src="assets/images/testimonial/testimonial-1-2.jpg" alt="">
                                        </div>
                                        <div class="testimonial-one__client-info">
                                            <h3 class="testimonial-one__client-name">Jessica brown</h3>
                                            <p class="testimonial-one__client-sub-title">Volunteer</p>
                                        </div>
                                        <div class="testimonial-one__quote">
                                            <span class="icon-double-quotes"></span>
                                        </div>
                                        <p class="testimonial-one__text-2">Nulla ultricies justo sit amet ante
                                            efficitur, eget pharetra augue efficitur. Vestibulum viverra, dolor sit amet
                                            ultricies simply free text ornare, elit justo pretium tellus.</p>
                                    </div>
                                    <!--Testimonial One Single End-->
                                </div>
                                <div class="item">
                                    <!--Testimonial One Single Start-->
                                    <div class="testimonial-one__single">
                                        <div class="testimonial-one__shape-1"
                                            style="background-image: url(assets/images/shapes/testimonial-one-shape-1.png);">
                                        </div>
                                        <div class="testimonial-one__client-img">
                                            <img src="assets/images/testimonial/testimonial-1-3.jpg" alt="">
                                        </div>
                                        <div class="testimonial-one__client-info">
                                            <h3 class="testimonial-one__client-name">Mike hardson</h3>
                                            <p class="testimonial-one__client-sub-title">Volunteer</p>
                                        </div>
                                        <div class="testimonial-one__quote">
                                            <span class="icon-double-quotes"></span>
                                        </div>
                                        <p class="testimonial-one__text-2">Nulla ultricies justo sit amet ante
                                            efficitur, eget pharetra augue efficitur. Vestibulum viverra, dolor sit amet
                                            ultricies simply free text ornare, elit justo pretium tellus.</p>
                                    </div>
                                    <!--Testimonial One Single End-->
                                </div>
                                <?php
$result = $db_handle->runQuery("select * from gallery");

foreach($result as $row) { ?>
                                <div class="item">
                                    <!--Testimonial One Single Start-->
                                    <div class="testimonial-one__single">
                                        <div class="testimonial-one__shape-1"
                                            style="background-image: url(admin/<?php echo $row['image'];?>);">
                                        </div>
                                        <div class="testimonial-one__client-img">
                                            <img src="assets/images/testimonial/testimonial-1-1.jpg" alt="">
                                        </div>
                                        <div class="testimonial-one__client-info">
                                            <h3 class="testimonial-one__client-name"><?php echo $row['heading'];?></h3>
                                            <p class="testimonial-one__client-sub-title"><?php echo $row['subheading'];?></p>
                                        </div>
                                        <div class="testimonial-one__quote">
                                            <span class="icon-double-quotes"></span>
                                        </div>
                                        <p class="testimonial-one__text-2"><?php echo $row['decription'];?></p>
                                    </div>
                                    <!--Testimonial One Single End-->
                                </div>
                                <?php } ?>
                            </div>
                        </div>
                    </div>
                    <div class="col-xl-2 col-lg-2">
                       
                       </div>
                </div>
            </div>
        </section>
        <!--Testimonial One End-->
        <!--Counter One Start-->
        <section class="counter-one">
            <div class="container">
                <div class="counter-one__inner">
                    <div class="counter-one-bg" data-jarallax data-speed="0.2" data-imgPosition="50% 0%"
                        style="background-image: url(assets/images/backgrounds/counter-one-bg.jpg);"></div>
                    <ul class="list-unstyled counter-one__list">
                    <?php
$result = $db_handle->runQuery("select * from count");

foreach($result as $row) { ?>
                        <li class="counter-one__single">
                            <div class="counter-one__count-box">
                                <h3 class="odometer" data-count="<?php echo $row['count'] ?>">00</h3>
                            </div>
                            <p class="counter-one__text"><?php echo $row['heading'] ?></p>
                        </li>
                        <?php } ?>
                    </ul>
                </div>
            </div>
        </section>
        <!--Counter One End-->

        <?php include 'footer.php' ?>